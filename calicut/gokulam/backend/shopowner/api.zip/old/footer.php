            <footer class="footer">
                <div class="container-fluid">
                    <nav class="pull-left">
                        <ul>
                           
                        </ul>
                    </nav>
                    <p class="copyright pull-right">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                       <a href="#">CSC</a> People, Passion, Excellence
                    </p>
                </div>
            </footer>