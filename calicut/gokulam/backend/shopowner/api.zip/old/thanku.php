<?php
$date=$_POST['date1'];

echo $date;


?>