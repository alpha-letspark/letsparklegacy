<?php
$number= 205463;
$last= substr(strip_tags($number), 2,4);

echo $last;

?>

