<?php
$sql = mysql_connect("localhost","mintmall","mint123321");
if(!$sql)
{
	echo "Connection Not Created";
}
$con = mysql_select_db("mintmall");
if(!$sql)
{
	echo "Database Not Connected";
}

?>