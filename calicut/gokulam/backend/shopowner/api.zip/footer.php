            <footer class="footer">
                <div class="container-fluid">
                    <nav class="pull-left">
                        <ul>
                           
                        </ul>
                    </nav>
                    <p class="copyright pull-right">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                       ©Alpha Innovative Ventures 2018
                    </p>
                </div>
            </footer>