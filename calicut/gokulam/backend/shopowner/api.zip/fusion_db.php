<?php
$hostdb = "localhost";  // MySQl host
   $userdb = "focusnewdemo";  // MySQL username
   $passdb = "focusnewdemo123321";  // MySQL password
   $namedb = "focusnewdemo";  // MySQL database name

   // Establish a connection to the database
   $dbhandle = mysqli_connect($hostdb, $userdb, $passdb, $namedb);

   /*Render an error message, to avoid abrupt failure, if the database connection parameters are incorrect */
   if (!$dbhandle) {
  	exit("There was an error with your connection: ".mysqli_connect_error());
   }
   
?>