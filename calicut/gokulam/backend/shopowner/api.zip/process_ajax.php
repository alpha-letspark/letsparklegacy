<?php
  mysql_connect('localhost', 'root', 'password') or die('Could not connect: ' . mysql_error());
  mysql_select_db('focusmall') or die('Could not select database');
   

  $placeId = $_POST['placeId'];

  $query = "SELECT * from employee_list";
  $result = mysql_query($query) or die('Query failed: ' . mysql_error());
  while ($row = mysql_fetch_assoc($result)) {
    if ($placeId == $row['name']){
      echo json_encode($row);
    }
  }
  
?>